from distutils.core import setup

setup(
    name='Resnext',
    version='0.1.0',
    author='Danila Lapko',
    author_email='danlapko@yandex.ru',
    packages=['Resnext'],
)
